> ✨ **Note:** This is an opensource Web Application for [Food Devlivery](https://react-quick-food.firebaseapp.com/).

### [Live demo](https://react-quick-food.firebaseapp.com/)

## Getting Started

- Install dependencies by running `yarn` or `npm install`.
- Run `yarn start` or `npm run start` to start the local development server.
- 😎 That's it! You're ready to start building awesome application.
